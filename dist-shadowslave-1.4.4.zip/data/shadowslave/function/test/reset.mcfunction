# Wipes verification state, Aspect/Flaw tags and modifiers for a clean test run.

# Get out of the nightmare first if we are in it. This function clears ss_in_nightmare, and
# beds do not work in that dimension — without this, running reset from inside strands you.
execute if entity @s[tag=ss_in_nightmare] run function shadowslave:nightmare/leave

advancement revoke @s from shadowslave:test/root
advancement revoke @s only shadowslave:enter_nightmare

scoreboard players set @s ss_rank 0
scoreboard players set @s ss_timer 0
scoreboard players set @s ss_aspect 0
scoreboard players set @s ss_flaw 0
scoreboard players reset @s ss_gone

tag @s remove ss_in_nightmare
tag @s remove ss_carrier
tag @s remove ss_creature_spawned
tag @s remove ss_test_bypass
tag @s remove ss_aspect_shadow
tag @s remove ss_aspect_flame
tag @s remove ss_aspect_bone
tag @s remove ss_aspect_wind
tag @s remove ss_flaw_shadow_slave
tag @s remove ss_flaw_fragile
tag @s remove ss_flaw_ravenous
tag @s remove ss_flaw_weightless

attribute @s minecraft:generic.armor modifier remove shadowslave:aspect_bone_armor
attribute @s minecraft:generic.movement_speed modifier remove shadowslave:aspect_wind_speed
attribute @s minecraft:generic.max_health modifier remove shadowslave:flaw_fragile_health
attribute @s minecraft:generic.safe_fall_distance modifier remove shadowslave:flaw_weightless_fall

execute in shadowslave:nightmare run kill @e[tag=ss_creature]
bossbar set shadowslave:trial visible false
bossbar set shadowslave:trial players

# Untouched, not a Sleeper: this clears ss_carrier, and Sleeper is the rank you hold once
# the Spell has marked you. soul.mcfunction makes the same distinction.
tellraw @s {"text":"[Shadow Slave] Verification state reset. You are Mundane again.","color":"gray","italic":true}
